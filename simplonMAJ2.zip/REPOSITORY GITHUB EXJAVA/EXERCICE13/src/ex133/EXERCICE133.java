
/*Exercice 13
1.demander à un utilisateur de saisir une chaine de caractère
2.demander à cet utilisateur de saisir une lettre
3.calculez le nombre de fois où cette lettre est présente dans la chaine saisie en 1.


*/



package ex133;

 import java.util.Scanner; 
public class EXERCICE133 {
   public static void main(String[] args) {

	   Scanner sc = new Scanner(System.in);
	   
       String phrase ;
       int i, nombre ;
       char lettre ;

       System.out.print("Saisissez une phrase : ");
       
       phrase = sc.nextLine();

       for (lettre=(char) 65; lettre<= 90; lettre++)
       {
           nombre=0;

           for(i=0; i<phrase.length(); i++)
           {
               if (lettre == phrase.charAt(i) || (lettre + 32) == phrase.charAt(i))
               {
                   nombre++;
               }
           }

           if (nombre > 0)
           {
           System.out.println(lettre +" = "+nombre);
           }
       }  
   }
}
   
   
   /* int nbchar = 0 ;
	   char nbChar =0;
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Saisir une chaine de caractère = ");
	   String caractere =  sc.nextLine;
    String caractere1= caractere.length();
	   System.out.println("Vous avez saisi  = "  + caractere);
	   
	     
  for (HashMap.Entry<type1, type2> entry : tamap.entrySet())
{
  entry.getKey();
  entry.getValue();
}
  
  /* Scanner lettre1 = new Scanner(System.in);
	  System.out.println("Saisir une lettre = ");
	    char lettre  = lettre1.findInLine(".").charAt(0);
	    System.out.println("Vous avez saisi  = " + lettre);
	 if (caractere) {
		 System.out.println("test");
		 
  
		 
	 }



		
	  System.out.println("Il y a " + nbchar + "  caracteres  " + lettre +  "   dans la ligne de caractère");
			
			   

}
/*
       {    Scanner question = new Scanner(System.in);
System.out.println("veuillez choisir une lettre =  ");          //afficher text
               String user = question.nextLine();                      //recuperer reponse

       {Scanner test = new Scanner(System.in);
System.out.println("veuillez valider votre choix");
           String pigeon = question.nextLine();}

System.out.println("merci passons a la suite");
           int compteur = -1;


       for (int i=0; i <3; i++) {                                  // boucle en i qui se lancera 3fois

       Scanner reader = new Scanner(System.in);
System.out.println("Veuillez choisir un mots  :");          //afficher text;
       String poulet = reader.nextLine();
        question.hasNextBoolean(); 

            boolean pigeon = true ;
       if(pigeon=true ) 
           compteur++ ;

System.out.println(pigeon+" est present dans un de vos mots");
System.out.println(user+" est present " +compteur);

         if(pigeon=false) compteur= +0;}

System.out.println("desoler votre selection ne fonctionne pas" );
*/ 










	   
  


 
