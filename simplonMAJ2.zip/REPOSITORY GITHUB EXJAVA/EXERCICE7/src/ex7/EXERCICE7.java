package ex7;
import java.util.Scanner; 
public class EXERCICE7 {
	public static void main(String[] args) {
	
		
		int testgit=0;
		
		// multiplie les 2 chiffres saisie au clavier et mettre le tout dans une boucle
		// variable premiernombre, deuxiemenombre, premiernombre1,premiernombre
		
		      System.out.println("Saisissez un chiffre");
			Scanner premiernombre = new Scanner(System.in);
	        int premiernombre1 = premiernombre.nextInt(); 
			Scanner deuxiemenombre = new Scanner(System.in); 
			int deuxiemenombre2 = deuxiemenombre.nextInt(); 
			System.out.println(premiernombre1*deuxiemenombre2);
		
}
}
// while do for system.out.println 