package ex11;
//Exercice 11 Calculez et affichez la valeur de 4/3 sans faire d'arrondi




public class EXERCICE11 {
	
	public static void main(String[] args) {
	
	
	double nb = 4; 
    double nbc = 3 ; 
	
	
	System.out.println("" + (nb/nbc));
}
}