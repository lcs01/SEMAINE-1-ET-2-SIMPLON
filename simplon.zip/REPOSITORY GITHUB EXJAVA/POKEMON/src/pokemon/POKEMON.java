package pokemon;
  import java.util.Objects;
import java.util.Scanner;

public class POKEMON {

		  public static void main(String[] args) {
			
		
			      Scanner sc = new Scanner(System.in);
			      
			  			  //////////////////
			  			  ////Variables////
			  			  ////////////////

			          ////////////////
			          /////ETAT //////
			          ////////////////
			           int sante = 50;
		               String  Santé =("Votre santé est maintenant de " + sante);

			          /////////////////
			          /////Attaques///
			          ////////////////
			  		    int degat = 20;
			  		    int poison = 1;
			          boolean fire = true; 
			          int fire1 = 20; 
			          //////////////////
			          ///// Pouvoir/////
			          //////////////////
			  		    int pouvoir = 10; 
			  		    int newlife = 2;
			          String choix = "";
			          boolean potion = false;
			        
			  
                
			      System.out.println(Santé);
			 
			  		System.out.println("Oh mon dieu un lucas sauvage vous attaque");

			  		sante -= degat;

			  		System.out.println("Vous avez  perdu " + degat + " point de vie");
			  		System.out.println("il vous reste " + sante + " point de vie");
			  		System.out.println("Oh mon dieu luca vous a empoisoner");
			      
			      System.out.println("Une potion ce trouve par terre voulez vous la prendre ? (oui ou non)");
			        choix = sc.nextLine();
			        switch(choix) {
			          case "oui":
			          System.out.println("Vous avez ramasser une potion");
			            potion = true;
			            break;
			          case "non" :
			          potion = false;
			          default:
			          System.out.println("désoler saisis incorecte vous ne prenez pas la potion");
			          potion = false;
			        } 
			        
			        
			        
			  		  for(int i = 0; i < 10; i++){
			          if (potion ){
			            System.out.println("vous avez bus une potion");
			            sante -= poison;
			            i = 10;
			          }else {
			            sante -= poison;
			          }
			  		    System.out.println("le poison vous a fait " + poison + " degat");
			  		  }
			  	
			      System.out.println("Votre santé est maintenant de " + sante );
			  		  

			  		sante += pouvoir ;
			  		System.out.println("Pouvoir de recuperation + " + pouvoir + " santé ");
			  		System.out.println("Votre santé est maintenant à " + sante);
			  		
			  		  
			  		for (int i = 0; i < 15; i++) {
			  			sante += newlife; 
			  			System.out.println("Vous avez invoqué newlife " + newlife +" santé ");
			  		}

			      System.out.println("Votre santé est maintenant de " + sante );
			      
			      System.out.println("Attention un dragon vous attaque");
			        System.out.println("Vous lui tirez dessus?");
			        
			       if(fire){
			       System.out.println("Le dragon a riposté avec une boule de feu   - " + fire1 +"degats");       
			       }else {
			         System.out.println("Le dragon est mort !");
			       }

			       System.out.println("Votre santé est maintenant de " + sante);

              }
			      }

		
			        
			      
			  		  

