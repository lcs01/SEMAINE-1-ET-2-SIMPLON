package ex16;
import java.util.Scanner;

/*Exercice 16
demandez la saisie d'un mot
Déterminez si ce mot est un palindrome*/


public class EXERCICE16 {
	public static void main(String[] args) {
	

			
		
			 
	//// String à deux variables , guillemets ouvert 
			      String original, reverse = ""; // Objects of String class  /// déclares la variable 
			      
			      // Scan la variable in , enregistre les touches saisies 
			      Scanner in = new Scanner(System.in);
			      // afficher cette phrase 
			      System.out.println("Enter a string to check if it is a palindrome");
			      
			      
			      original = in.nextLine();       /// dis que la variable original est égale aux touches saisies dans le scanner in 
			     
			      
			      /// la variable int contient la longueur de la chaine String 
			      int length = original.length();
			     
			      /// boucle contenant la longueur "length" de la chaine String 
			      for (int i = length - 1; i >= 0; i--) {// longueur en sens inverse , longueur = - 1 , i est plus grand ou égale à 0 
			    	  //// i se décremente 
			         reverse = reverse + original.charAt(i);  // la variable reverse  est égale à elle meme plus 
			      }
			      
			      /// les deux variables original et reverse sont égales alors 
			      if (original.equals(reverse)) {
			         System.out.println("The string is a palindrome."  + original  + reverse);
			      }
			     /// sinon 
			      else {
			    	  
			    	  //// afficher cette phrase 
			         System.out.println("The string isn't a palindrome.");
			         
			   
			   
			      
			
		
			      }
		
	}}
		
		
		
	
	
	
	
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////TENTATIVES , BROUILLONS /////////////////////////////TENTATIVES , BROUILLONS /////////////////////////////
	////////////////////TENTATIVES , BROUILLONS ///////////////////////////TENTATIVES , BROUILLONS ////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
		
		/*
		int i;
		for(i = 0 ; i <3 ; i++) {
		System.out.println("Donnez un prénom : ");
	
		Scanner sc = new Scanner (System.in);
		
		String scan = sc.nextLine();
		
boolean test = true;
		i = Integer.parseInt(scan); 
		if (test == true) {
		/// utiliser methode pour changer un string en int // utiliser une boucle pour lire le int dans les 2 sens for next 
	    System.out.println(i);
			sc.close();
		}
		}
	
	//	Scanner scann = new Scanner (System.in);
		//String scan2 = sc.nextLine();
	//	int test = String.valueOf(String scan) ;*/
            
	//String str1 = new String(scan), str2 = new String(scan2);
		//if (str1.equals(str2))
		//  System.out.println("Le mot est un palyndrome!");
		//else

		  //System.out.println("Le mot n'est pas un palyndrome");

/*
 * 
 * 
 * un palindrome est un mot qui se lit pareil dans les 2 sens
 * 
 * 
 * ANNA
 * ----> 1er boucle               boolean true 
 * <---- 2e boucle                boolean true 
 * 1234
 * 4321 
 * BOB 
 * 123
 * 321
 * 
 * deux boucles différentes 
 * chacune dans un sens aller-retour 
 * déterminez que le retour est l'inverse exact de l'aller 
 * 
 * 
 *
 * que le scanner lise le mot dans un sens l'enregistre dans une valeur true
 *  puis réenregistre le mot dans le sens inverse dans une autre boucle
 *  
 * 
 * 
 * 
 * 
 * 
		String input = "1 fish 2 fish red fish blue fish";
	     Scanner s = new Scanner(input);
	     s.findInLine("(\\d+) fish (\\d+) fish (\\w+) fish (\\w+)");
	     MatchResult result = s.match();
	     for (int i=1; i<=result.groupCount(); i++)
	         System.out.println(result.group(i));   */
	 
	




