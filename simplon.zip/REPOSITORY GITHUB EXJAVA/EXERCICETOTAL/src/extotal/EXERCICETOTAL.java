package extotal;

import java.util.Scanner;

public class EXERCICETOTAL {
	public static void main (String[] args) {

		/*Exercice 03
3.1– Ecrivez un programme (une classe ) qui réalise les opératons suivantes :
• demander son nom à un utlisateur
• l’utlisateur doit saisir dans la console son nom + [entrée]
• le programme doit ré-afcier en console le nom saisi par l’utlisateur.
3.2 à partr du résultat du 1.1 écrivez un programme qui demande son nom à un utlisateur et qui ensuite dit bonjour à cet utlisateur en
l’appelant par son nom.*/
		int boucle = 0;
		/// tant que 
		while (boucle == 0) {
			//afficher une phrase 
			System.out.println(" EXERCICE 3 ");
			System.out.println("Quel est ton nom ?? ");
			// enregistrer la saisie du texte 
			Scanner sc = new Scanner(System.in);
			//permet de passer à la ligne
			String name = sc.nextLine();
			System.out.println("Bonjour   " + name);



			/*Exercice 04
Ecrire la table de multplicaton de 3 (pour les valeurs de 0 à 10)
			 */
			System.out.println(" EXERCICE 4 ");
			System.out.println("Maintenant regarde la table de multiplication   de 3  :");


			for(int o = 0; o<11; o++){

				System.out.println(3*o);

				if (o == 10){
					/*Exercice 05
Même ciose mais l'utlisateur doit cioisir le nombre.*/
					System.out.println(" EXERCICE 5 ");
					System.out.println("Tu dois maintenant choisir un nombre   : ");
					Scanner nombre = new Scanner(System.in);
					int nombre1 = nombre.nextInt();

					System.out.println("C'était cool !! Tu peux choisir deuxieme nombre    : ");
					Scanner nombre2 = new Scanner(System.in);
					int nombre3 = nombre2.nextInt();

					if(nombre1 <= 0){
						System.out.println("!ERREUR!");

					}
					else {

						System.out.println(nombre1 + "*"+ nombre3 + "= "+(nombre1*nombre3));


					}
					/*Récupérer la saisie de 2 nombres entiers, puis la saisie d'un opérateur '+', '-', '*' ou '/'.
Si l'utilisateur entre un opérateur erroné, le programme affichera un message d'erreur.
Dans le cas contraire, le programme effectuera l'opération demandée (en prévoyant le
cas d'erreur "division par 0"), puis affichera le résultat.
hypothèses :
- les bornes -1000 et 1000 sont acceptées
- si l'opérateur n'est pas correct, on effectue une addition
V0 : pas de prise en compte de la conception du programme (séparation entre trt et affichage)*/


					// affiche le texte entre parenthèse 

					System.out.println("  EXERCICE 6   ");
					System.out.println(" Saisissez un chiffre :  ");
					// enregistrer la saisie clavier 
					Scanner nb = new Scanner(System.in);
					int nb1 = nb.nextInt();
					System.out.println(" Saisissez un deuxieme chiffre : ");
					Scanner nb2 = new Scanner(System.in);
					int nb22 = nb2.nextInt();
					System.out.println(" Saisissez un operateur  : + , - , /  ou *   :");
					Scanner operateur = new Scanner(System.in);
					char op = operateur.nextLine().charAt(0);

					switch(op) {
					case '+': 
						System.out.println(nb1 + nb22);
						break;

					case '-':

						System.out.println(nb1 - nb22);
						break;

					case '*':
						System.out.println(nb1 * nb22);

						break;

					case '/':
						System.out.println(nb1/nb22);

						break;

					default:
						System.out.println("L'operateur est incorrect, on procède donc a une addition : " + (nb1+nb22));

					}
					System.out.println(" EXERCICE 7 ");
/*Exercice 07
Ecrire un programme qui calcule les N premiers multiples d'un nombre entier X, N et X
étant entrés au clavier.
Il est demandé de choisir la structure répétitive (for, while, do...while) la mieux
appropriée au problème.
On ne demande pas pour le moment de gérer les débordements (overflows) dus à des
demandes de calcul dépassant la capacité de la machine.
*
* **************************************************** Cherchez l'erreur ...
*/
					
					
				System.out.println("Saisissez 2 chiffres");
				Scanner ex7 = new Scanner(System.in);


				}







				// deuxieme boucle for 
			}
			//premier boucle for 
		}
		//class && public static void 
	}}

