package ex9;
	import java.util.Scanner;
public class EXERCICE9 {
	//


	  public static void main(String[] args) {

	    ///////////////////////////
	    //////Scanner de l'age ////
	    ///////////////////////////
	    Scanner age = new Scanner(System.in);
	    /////////////////
	    //////Variable///
	    ////////////////
	    
	    int jeune = 0;
	    int ageMoyen = 0;
	    int vieux = 0;
	    int ages = 0;
	    int centAns = 0;
	    int Erreur = 0;
	    
	    /////////////////
	    //////End///////
	    ////////////////
	    
	    for (int i = 1; i < 20; i++){ // i = compteur 
	      System.out.println("tour numero" + i);
	      System.out.println("Quel age as tu ? ");    
	      ages = age.nextInt();
	      
	        if (ages < 20){  // si age inferieur a vingt alors
	          System.out.println("jeune");  //Jeune
	          jeune ++;
	         
	          
	        } else if (ages > 20 && ages < 40){ // si age est entre vingt et quarante alr
	          System.out.println("ageMoyen"); // ageMoyen
	          ageMoyen ++; 
	         
	        } else if (ages >= 41 && ages < 100){
	          System.out.println("vieux");  //Vieux
	         vieux ++; 
	        } else if (ages == 100) {
	          System.out.println("waow un centenaire");
	          i = 20; // le for est donc a 20 il ne fait plus de tour !!
	          centAns++;
	         
	        } else  {
	          Erreur ++;
	          System.out.println("Erreur");
	     
	        }
	      
	        
	      }
	    
	  
	    System.out.println("il y  a " + jeune + "  personnes d'age jeunes dans votre etablissement !");

	    System.out.println("il y  a " + ageMoyen + " personne d'age moyenne dans votre etablissement !");
	     
	    System.out.println("il y  a " + vieux  + " vieux dans votre etablissement !");
	      
	    System.out.println("il y  a " + Erreur + "  Erreurs");


	}
	  
	        


	   


	/*Exercice 09
	Reprenez l'échantillon de personnes de l'exercice 08
	Il s’agit maintenant de dénombrer les personnes d'âge inférieur strictement à 20 ans, les
	personnes d'âge supérieur strictement à 40 ans et celles dont l'âge est compris entre
	20 ans et 40 ans (20 ans et 40 ans y compris).
	Enfin il s'agit de faire l'opération précédente en ajoutant la contrainte ci-dessous.
	Le comptage est arrêté dès la saisie d’un centenaire. Le centenaire est compté.
	Pour chacune des demandes ci dessus, donnez le programme java correspondant qui affiche les résultats.*/

}
