package ex3;

import java.util.Scanner;

public class EXERCICE3 {

	public static void main(String[] args) {  
		Scanner in = new Scanner(System.in);  
		System.out.println("Input the Number: "); 
		int n = in .nextInt();   for (int i = 1; i <= 10; i++) {
			System.out.println(n + "*" + i + " = " + (n * i));
			}  } 

}
