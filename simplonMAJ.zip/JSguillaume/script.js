/////////////////////////////////////////////////////////
//////////////// 1ere boite de dialogue ////////////////
//////////////////////////////////////////////////////////

alert("!EXERCICE 1!");
var prenom = prompt("Entrez le prénom de votre Pokemon  :");
var prenom1 = prenom.length ;//nombre de lettre dans le prenom

if(prenom1 <= 10 && prenom1 >=0) {
  alert("Vous avez choisi "+ prenom);
    alert("Il y a  "+ prenom1 +"  caracteres dans  "+ prenom);
  
}
else {
alert("Erreur!! Choisissez un prénom plus court !!! ");

}

 function metEnInline(){
      document.getElementById('boite1').style.display = "inline-block";
      document.getElementById('boite2').style.display = "inline-block";
      document.getElementById('boite3').style.display = "inline-block";
    }

    function metEnBlock(){
      document.getElementById('boite1').style.display = "block";
      document.getElementById('boite2').style.display = "block";
      document.getElementById('boite3').style.display = "block";
    }



//////////////////////////////////////////////
//////////// Calculette /////////////////////
//////////////////////////////////////////////
alert("!EXERCICE 2 : Calculette!");

  var nombre = prompt("Choisir un nombre  : ");
  //on choisie le premier nombre
    var operateur = prompt("choisir un operateur  : ");
  //choisie le signe
  var nombre2 = prompt("Choisir un autre nombre  : ");
  //on choisie le deuxième nombre 


      switch (operateur) {
    //si l'opération est une addition:
    case "+" :
    var nbResult =parseInt(nombre) +parseInt(nombre2) ;
              alert(nbResult);

      break;
    // si l'opération est une soustraction:
    case "-" :
       var nbResult =nombre -nombre2;
        alert(nbResult);
      break;
    // si l'opération est une multiplication :
    case "*" :
        var nbResult =nombre *nombre2;
       alert(nbResult);
      break;
    // si l'opération est une soustraction :
    case "/" : 
           var nbResult =nombre /nombre2;
                  alert(nbResult);
              break;

    default: // verifier le default place etc 
               var defaut = prompt("erreur");
  }
      //on lui indique que le paramètre b doit être différent de 0 car on ne peut diviser par 0 :
    /*  if ( nombre2 !== 0){
        return nombre / nombre2 ;}
      else{
        return Infinity ;
      
   */
      //// verifier le if le case le break 
  
    //si l'opération est un modulo (afficher le reste de la division) :
  
 