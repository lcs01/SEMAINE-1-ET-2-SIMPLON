/* Exercice 18
Demandez une saisie d'un entier entre 0 et 256 puis afficher cet entier et sa conversion en char */



package ex18;
import java.util.Scanner;
public class EXERCICE18 {
    public static void main (String[] args) {
    	System.out.println("Saisissez un entier entre 0 et 256 ");
    	Scanner sc = new Scanner(System.in);
    	int scan = sc.nextInt();
    	char test  = (char) scan;
    	System.out.println(test);
    	
   // 	if(scan != )
    	
   
    
    
    
    }
}
