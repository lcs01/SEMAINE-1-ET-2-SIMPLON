/*Exercice 23
Demandez à l'utilisateur de saisir un nombre
Ecrivez la méthode qui retourne cette valeur élevé à la puissance 3.
utilisez cette méthode pour retourner la saisie de l'utilisateur à la puissance 3.*/



package ex23;
import java.util.Scanner;

public class EXERCICE23 {
	public static void main (String[] args) {
		System.out.println("Saisir un nombre ");
		Scanner sc = new Scanner (System.in);
		int Scan = sc.nextInt();
		
	
		
	}
	}
	
	
	
	
	
	
	


