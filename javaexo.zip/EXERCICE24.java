package ex24;
import java.util.Scanner; 
public class EXERCICE24 {
	public static void main (String []args) {
		
		
		
		
	}
	}


