package ex12;
import java.util.Scanner;
public class EXERCICE12 {
		public static void main(String[] arg){
			Scanner sc = new Scanner(System.in); 
			System.out.println("Quel est ton nom?");
			String pl = sc.nextLine();
		System.out.println("Bonjour " + pl); 
		}
}
