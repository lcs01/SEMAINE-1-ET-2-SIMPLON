package ex15;
import java.util.Scanner;
public class EXERCICE15 {
	public static void main(String [] args ) {
		/*Exercice 15
		Demandez la saisie d'un mot à l'utilisateur
		Afficher les trois derniers caractères de ce mot
		Afficher ce mot sans les deux premier caractère et sans les trois dernier caractères
		(NB : Gérez le cas où le mot n'est assez long )*/
		
		System.out.println("SAISISSEZ UN MOT : "); // afficher ce texte
		Scanner sc = new Scanner(System.in); // enregistre la saisie
		String mot = sc.nextLine();  // recupere la saisie dans une  variable string
	      
		int longueur = mot.length();
		System.out.println(longueur);
		
	//	int longueur2[]  = {nbChar}
		char nbChar = mot.charAt(longueur);
		
		System.out.println(nbChar);
		
		sc.close();
		
	}// public class
	}// public static
		
		
		
		
	/*	
		
		
		int [] motTab = {mot.length()};  // contient un tab
		if(motTab[1]<=100) {
			
			
		}
		System.out.println(motTab);
	}}
		
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	/*//	int length= mot.length()charAt();  // la variable length contient la longueur de mot 
		
		 String test = "test";   // variable contient test
		  int length = test.length();  // variable contient la longueur de test
		 char testChar= test.charAt(length); // variable char contenant la longueur 
		 char []  caractere = {'l'};
		 System.out.println(caractere);
	  
			   //   char result = mot.length.()charAt();
			//      System.out.println(result);
	//		      System.out.println(test);
			
		
	//	 int n = 3 ;    // variable n qui sert à utiliser la variable result plus bas 
	//	 int length = mot.length();  // variable qui englobe la longueur du mot
	//	String result = mot.substring(length -n, length); // variable String qui englobe 
	/// 
		
     /// la variable result est égale à l'opération qui contient
		
		
		// System.out.println(result);
	*/	
		
		
	


