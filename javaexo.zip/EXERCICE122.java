package ex122;
/*Exercice 12
Déclarez une variable de type tableau de 5 entiers.
Remplissez ce tableau avec des valeurs aléatoires comprises entre 0 et 10.
Indiquez si la valeur 4 est dans le tableau, si oui indiquez sa position.*/




public class EXERCICE122 {
	public static void main (String[]  args) {
		
		int first = (int)(Math.random()*10 +1);      ///// 1 entier 
		int second = (int)(Math.random()*10 +1);    /////// 2eme entier
		int three = (int)(Math.random()*10 +1);    ////////// 3eme entier 
		int four = (int)(Math.random()*10 +1);    ///////////// 4eme entier 
		int five = (int)(Math.random()*10 +1);   /////// 5eme entier 
		
		int tab1[] = {first, second, three, four,five};
		
		
		System.out.println("valeur first is " + tab1[0]);

		System.out.println("valeur second is " + tab1[1]);

		System.out.println("valeur three is " + tab1[2]);

		System.out.println("valeur four is " + tab1[3]);

		System.out.println("valeur five is " + tab1[4]);
		
		int yes = 4;
		
		if(first == 4) {
			System.out.println("the variable first = 4  and this position is 0");
		}

		else if(second == 4) {
			System.out.println("the variable second = 4  and this position is 1 ");
		}

		else if(three == 4) {
			System.out.println("the variable three = 4  and this position is 2  ");
		}
		
		

		else if(four == 4) {
			System.out.println("the variable four = 4 and this position is 4");
		
		}
		
		
		

		else if(five == 4) {
			System.out.println("the variable five =  4  and this position is 4");
			
		}
		
		else {}
		
		
		
		
		
		
		
		
		
	}
	}


