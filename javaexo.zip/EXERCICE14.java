/*Exercice 14
1.demander à un utilisateur de saisir une chaine de caractère
2.retournez cette chaine en majuscule
3.retournez cette chaine avec la première lettre en majuscule*/
//fini 
/////////finish

package ex14;

import java.util.Scanner; // le scanner peut marcher
public class EXERCICE14 {
	public static void main(String[] args) {
		
		
		System.out.println("Saisir une chaine de caractère   : "); /// afficher cette phrase
		Scanner chaine = new Scanner(System.in);  // entrée in enregistre la saisie dans chaine
		String chaine1= chaine.nextLine();  // defini chaine en une variable String 
		String chaineNew = new String(chaine1.toUpperCase()); // transformer la chaine1 en chaineNew
		// la chaineNew est égale à la chaine1 avec les caracteres en Majuscule
		System.out.println(chaineNew);  // afficher chaineNew
	
		//// NOUVELLE CHAINE AVEC 1ere LETTRE EN MAJ 
		String chaineMaj=chaine1.replaceFirst(".",(chaine1.charAt(0) + "" ).toUpperCase());
		// creer une nouvelle variable chaineMaj qui contient la chaine1 avec le premier caractere modifié en Majuscule
	
		System.out.println(chaineMaj); // afficher chaineMaj
		
		chaine.close(); //fermer le scanner
		
	}/// public static 
	}//// public class 
		
		
		
	    //	int length = chaineNew.length();
		//for (int i = length; i<2; i++) {// longueur en sens inverse , longueur = - 1 , i est plus grand ou égale à 0 
	    	 
			//// i s'incrémente
	//      String chaineDER= chaineNew + chaineNew2.charAt(i);  // la variable reverse  est égale à elle meme plus 
	      
	//String chaineUp1 = new String (chaine1.toUpperCase());
		
	 //     String chaineDERDER =new String(chaineDER.toUpperCase());
	      
	      
	//	System.out.println(chaineDERDER);
		//int n = 3 ;    // 
		// int length = chaine1.length();
		 
	//	 System.out.println();
	//	Object result = (chaine1.toUpperCase();
		
	//	int length = chaineNew.length();
	//	String chaine3 = newString(chaineNew)
	  //	String chaine3 = length.substring(0, 1);
	//	System.out.println(chaine3);

		//String  testt, testtt = test.nextLine();

	    
	  //  System.out.println(testt1);
	      
	    
	    
	   /* char ;	     String testt1 = null, testtt2 = new String(testt1 +testtt2.toUpperCase());

	//      int length = testt1.length();
	   //   for (int i = length - 1; i >= 0; i--) {// longueur en sens inverse , longueur = - 1 , i est plus grand ou égale à 0 
	    	  //// i se décremente 
	       //  testt = testt + testtt.charAt(i);  // la variable reverse  est égale à elle meme plus 
	    //  }
	      
//	testt1 = new String(testt1.toUpperCase());
	//      }
		//String test3 , test2 = "";
	
		
		*/
		
	
	      
	      


