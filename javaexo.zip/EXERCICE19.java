/* Exercice 19 Tri à bulle
Déclarez et initialisez un tableau de 8 entiers.
Remplir aléatoirement ce tableau avec des nombres entre 0 et 100.
Afficher ce tableau en l'état.
Ecrivez l'algorithme qui trie un tableau d'entiers dans l'ordre croissant.
Ré-afficher le tableau une fois trié.*/






package ex19;
import java.util.Scanner;
public class EXERCICE19 {
	
	public static void main (String [] args) {
		
	/*	int monTableau[ ] = new int[10];
		monTableau = new int[]{11,13,17,19,23,29,40,50,60,90};
	
		System.out.println(monTableau); */
	/*	int tricroissant;
 		void tricroissant( int tab[], int tab_size)                                            
		{                                                                              
		  int i=0;                                                                     
		  int tmp=0;                                                                     
		  int j=0;                                                                     
		                                                                                 
		  for(i = 0; i < tab_size; i++)                                         
		    {                                                                          
		      for(j = 1; j < tab_size; j++)                        
		        {                                                                      
		          if(tab[i] < tab[j])                                                        
		            {                                                                  
		              tmp = tab[i];                                                          
		              tab[i] = tab[j];                                                       
		              tab[j] = tmp;                                                          
		              j--;                                                             
		            }                                                                  
		        }                                                                      
		    }                                                                          
		  tmp = tab[0];                                                                      
		  for(i = 0; i < tab_size; i++)                                             
		    tab[i] = tab[i+1];                                                               
		  tab[tab_size-1] = tmp;                                                                    
		} */ 
	
		
		
		
	}
	

}
