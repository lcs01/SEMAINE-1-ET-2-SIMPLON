package ex17;

import java.util.Scanner;

class EXERCICE17 {
	public static void main(String[] args) {

		System.out.println("saisie une lettre ou un mot  :  ");/// affiche
		System.out.println("------"); // affiche 
		Scanner sc = new Scanner(System.in); // enregistre saisie 
		String scan= sc.nextLine(); // variable contenant la saisie sc 
		// scan
		for(int i =0 ;i<10; i++ ) {  // boucle for dont la variable est  le nombre de caractere de scan 
			char Scanner= scan.charAt(i);  // je dis que la varaiable Scanner est égale à tous les caracteres de scan 
			char Scanner2= scan.charAt(0);  // je dis que la varaiable Scanner2 est égale au premier caractere de scan 
			char Scanner3= scan.charAt(1);  // etc 
			char Scanner4= scan.charAt(2); 
			char Scanner5= scan.charAt(3);
			char Scanner6= scan.charAt(4);
			char Scanner7= scan.charAt(5);
			//	System.out.println(Scanner2);
			char [] caractere = {'h','e','l','i','c','o'};  //test avec chaine de caractere 
			//	// // //  // // // // // //String PenduHelico= "helico";// // // // // // // // // // // // }

		
				String str = new String("-_");
				switch(Scanner) {       // dans scanner 
				//		case "":
				//		System.out.println("Yessssss You win : helico !!!");
				//		break;
				case 'h':  /// si il y a le caractere h  dans Scanner 
					System.out.println("Yessssss, you find the h"); // affiche 


					str = str.replace('-', 'h');
					System.out.println(str);

					break;
				case 'e':   // etc 
					System.out.println("Yessssss you find the e"); // etc 

					str = str.replace('_', 'e');
					System.out.println(str);
					break;
				case 'l':
					System.out.println("Yessssss you find the l");
					break;
				case 'i':
					System.out.println("Yessssss you find the i");
					break;
				case 'c':
					System.out.println("Yessssss you find the c");
					break;
				case 'o':
					System.out.println("Yessssss you find the o");
					break;
				default: //sinon
					if (caractere[0]==Scanner2&& caractere[1]==Scanner3&& caractere[2]==Scanner4&&caractere[3]==Scanner5&& caractere[4]==Scanner6&&caractere[5]==Scanner7) {
						System.out.println("helico ! vous avez reussi ");}
					else {
					System.out.println("MAUVAISE REPONSE "); // affiche
				
					}

					
				


			}


		}		}// public static 
}// class
/*  else if (caractere[1+2]==Scanner2+Scanner3) {
    	System.out.println("he----");
    }

		System.out.println();
       }}}
		//	char h = 'h'; */


//	if(Scanner==fin){
//		System.out.println("Yessssss,FIIIN you find the h");/		}




//
/*  
    //  }}}  /*
			if(caractere[0]==Scanner2) {
				System.out.println("Vous avez trouvé la lettre h !");
			}
			if(caractere[0+1]==Scanner3) {
				System.out.println("Vous avez trouvé la lettre e !");
			}	
			if(caractere[2]==Scanner4) {
				System.out.println("Vous avez trouvé la lettre l !");
			}	
			if(caractere[3]==Scanner5) {
				System.out.println("Vous avez trouvé la lettre i !");
			}
			if(caractere[4]==Scanner6) {
				System.out.println("Vous avez trouvé la lettre l !");
			}	
			if(caractere[5]==Scanner7) {
				System.out.println("Vous avez trouvé la lettre o !");
			}

			else {
				System.out.println("lol");
			}

  }
} */













/*
			String lettre = "";  //// déclarer la variable de la lettre saisie 
            String mot = "Banane";
            System.out.println("Devinez ce mot  de 6 lettres : "); //// afficher devinette 
			Scanner devine = new Scanner(System.in);  //// enregistre la saisie de devine 
            char Devine1= devine.nextLine().charAt(0);
            String devinette = devine.nextLine();
            int longueur = devinette.length();

            for(int i = 0; i <longueur;i++ ) {
            	System.out.println();

            }
            if(Devine1==mot) {



            }




			System.out.println("Devinez ce mot  de 6 lettres : "); //// afficher devinette 
			System.out.println("-----");//////////////////// afficher un mot 
			System.out.println("Saisissez une lettre");  ////////////// afficher la question 
		//	int length = lettre.length();    //////////// englobe la longueur de lettre dans une variable 

			 lettre = devine.nextLine();
			 char lettre1 = lettre.charAt(10); 
			 if (lettre1 == lettre.charAt(10) ) {


				 System.out.println(lettre);
			 }

			System.out.println(lettre1);
	      /* if (lettre= true) {
	    	   System.out.println("W-----");
	    	    }
	       else {
	    	   System.out.println("ERREUR");    */



/*	private static String charAt(int i) {
			// TODO Auto-generated method stub
			String test = "lol";

			return test;
		} */





/*	private static void charAt() {
			// TODO Auto-generated method stub*/ 








