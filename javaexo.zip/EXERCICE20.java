/*Exercice20
Déclarez et initialiser un tableau d'entiers à deux dimensions, dont la taille est deux pour la première dimension et
deux aussi pour la seconde dimension. Choisissez les valeurs à mettre dans ce tableau .
Ecrivez le programme java qui lit puis qui affiche ce tableau.*/



package ex20;
import java.util.Scanner;
public class EXERCICE20 {
	public static void main(String [] args) {
	
			      int[][] tableau;
			      int i, j;

			      tableau = new int[2][2];
			      for (i = 0;i < tableau.length; i++) {
			         for ( j = 0;j < tableau[i].length;j++) {
			            tableau[i][j] = i + j;
			            System.out.print(tableau[i][j] + " ");
			         }
			         System.out.println();
			      }
			      System.out.println();
		
		
	
	}

}
