/*Exercice 22
(Upgrade de l'exercice 14)
Demandez à l'utilisateur de saisir un mot
Ecrivez une méthode qui prend en paramètre une chaine de caractère et qui retourne cette chaine en majuscule.
Utilisez cette méthode pour retourner à l'utilisateur son mot en majuscule.*/




package ex22;
import java.util.Scanner;
public class EXERCICE22 {
	
	public static void main (String [] args) {
		System.out.println("Saisir un mot ");
		Scanner sc = new Scanner(System.in);
		String scan = sc.nextLine();
		
		
		
	}
	}

