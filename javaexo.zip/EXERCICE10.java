package ex10;


/*Exercice10
Déclarez et initialisez une variable tab1 de type tableau contenant les 4 éléments suivants : 4, 67, 25, 87.
Déclarez et initialisez une variable tab2 de type tableau contenant les 4 éléments suivants : 4.5, 67, 25.50, 87.00
Déclarez et initialisez une variable tab3 de type tableau contenant les 4 éléments suivant : 'r', '2', '?' , '+'.
Déclarez et initialisez une variable tab4 de type tableau contenant les 4 éléments suivant : "Robert",
"Noemie", "David" , "Bertrand".
Affichez le premier élément de tab1

Remplacez la valeur de tab1 qui vaut 25 par la valeur 42.
Afficher via ne boucle for , toutes les valeurs de tab3.
Affichez la taille de tab1
*/
public class EXERCICE10 {
	
	public static void main(String[] args){
		int tab1[]= {4, 67, 25, 87};
		double tab2[] = {4.5, 67, 25.50, 87.00};
		char tab3[] = {'r', '2', '?' , '+'};
		String tab4[]= {"Robert","Noemie", "David" , "Bertrand"};
		
		System.out.println("Le premier élement de tab1 est " + tab1[0]);
		tab1[2] = 42;
	System.out.println("est remplacé par "+ tab1[2]);
		for(int i=0; i<4 ; i++){
			System.out.println("Une valeur de la boucle for = " + tab3[i]);
		
			
		}
		
		System.out.println("La longueur de tab1 est égale à  " + tab1.length);
		}
		
		
		
	}
	
	




