/* Exercice 21

Ecrivez le programme Java qui lit deux matrices carrées dont la taille est fixée par une constante, en calcule la
somme puis affiche le résultat .
Indice : la somme de deux matrices se fait élément par élément . Si A et B sont les deux matrices dont C est la
somme, alors pour toute paire d'indices i et j, Cij=Aij+Bij */ 


package ex21;
import java.util.Scanner;
public class EXERCICE21 {
	
	public static void main (String [] args) {
	
		

		
		
		
	}}
		
		
		
		
		
		
		
		
		
		
		
		
	//	String banniere(String ban){
		
	/*    return  (Banniere) "*************************************************************\n" +
				"**\n" + 
				"**\n" + 
				"**\n" + 
				"BIENVENUE\n" + 
				"**\n" + 
				"**\n" + 
				"**\n" + 
				"*************************************************************");
	
		
		
		*/
	


